#!/bin/sh

function run {
    if ! pgrep $1 > /dev/null ;
    then
        $@&
    fi
}
run lxpolkit &
run picom --experimental-backends --backend glx --config $HOME/.config/picom.conf &
#volumeicon &
#dunst &
#run nm-applet &
run xfce4-power-manager &
#xfce4-screensaver &
#xfce4-clipman &
run redshift -c $HOME/.config/redshift.conf &
#ibus-daemon --daemonize &
run /usr/bin/ibus-daemon -dr &
#nitrogen --set-zoom-fill --restore &
#feh --bg-fill /usr/local/share/backgrounds/wallpapers-master/0015.jpg
run nitrogen --set-zoom-fill --restore &
run /usr/lib/xfce4/notifyd/xfce4-notifyd &
#flameshot &
