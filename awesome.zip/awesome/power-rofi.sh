#!/bin/sh
 
RET=$(echo -e "shutdown\nreboot\nlogout\ncancel" |rofi -dmenu -l 5 -p "Logout")
 
case $RET in
       shutdown) systemctl poweroff ;;
       reboot) systemctl reboot ;;
       logout) xdotool key "super+shift+q" ;;
       *) ;;
esac

